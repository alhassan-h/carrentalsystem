<?php 
	$dbc = new mysqli('localhost','root','','faultreport') or die("Connection Error: " . mysqli_connect_error());
?>